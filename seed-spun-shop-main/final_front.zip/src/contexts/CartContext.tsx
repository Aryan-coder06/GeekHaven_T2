import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { calculatePlatformFee, formatCurrency } from '@/utils/seed';

export interface CartItem {
  id: string;
  title: string;
  price: number;
  image: string;
  sellerId: string;
  sellerName: string;
  quantity: number;
}

interface CartState {
  items: CartItem[];
  subtotal: number;
  platformFee: number;
  total: number;
}

type CartAction =
  | { type: 'ADD_ITEM'; item: Omit<CartItem, 'quantity'> }
  | { type: 'REMOVE_ITEM'; id: string }
  | { type: 'UPDATE_QUANTITY'; id: string; quantity: number }
  | { type: 'CLEAR_CART' };

const initialState: CartState = {
  items: [],
  subtotal: 0,
  platformFee: 0,
  total: 0,
};

function cartReducer(state: CartState, action: CartAction): CartState {
  let newItems: CartItem[];
  
  switch (action.type) {
    case 'ADD_ITEM':
      const existingItem = state.items.find(item => item.id === action.item.id);
      if (existingItem) {
        newItems = state.items.map(item =>
          item.id === action.item.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        newItems = [...state.items, { ...action.item, quantity: 1 }];
      }
      break;

    case 'REMOVE_ITEM':
      newItems = state.items.filter(item => item.id !== action.id);
      break;

    case 'UPDATE_QUANTITY':
      if (action.quantity <= 0) {
        newItems = state.items.filter(item => item.id !== action.id);
      } else {
        newItems = state.items.map(item =>
          item.id === action.id
            ? { ...item, quantity: action.quantity }
            : item
        );
      }
      break;

    case 'CLEAR_CART':
      newItems = [];
      break;

    default:
      return state;
  }

  // Recalculate totals
  const subtotal = newItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const platformFee = calculatePlatformFee(subtotal);
  const total = subtotal + platformFee;

  return {
    items: newItems,
    subtotal,
    platformFee,
    total,
  };
}

interface CartContextType extends CartState {
  addItem: (item: Omit<CartItem, 'quantity'>) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  itemCount: number;
  formattedSubtotal: string;
  formattedPlatformFee: string;
  formattedTotal: string;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(cartReducer, initialState);

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('marketplace-cart');
    if (savedCart) {
      try {
        const parsedCart = JSON.parse(savedCart);
        parsedCart.items.forEach((item: CartItem) => {
          for (let i = 0; i < item.quantity; i++) {
            dispatch({ type: 'ADD_ITEM', item });
          }
        });
      } catch (error) {
        console.warn('Failed to load cart from localStorage:', error);
      }
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('marketplace-cart', JSON.stringify(state));
  }, [state]);

  const addItem = (item: Omit<CartItem, 'quantity'>) => {
    dispatch({ type: 'ADD_ITEM', item });
  };

  const removeItem = (id: string) => {
    dispatch({ type: 'REMOVE_ITEM', id });
  };

  const updateQuantity = (id: string, quantity: number) => {
    dispatch({ type: 'UPDATE_QUANTITY', id, quantity });
  };

  const clearCart = () => {
    dispatch({ type: 'CLEAR_CART' });
  };

  const itemCount = state.items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        ...state,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        itemCount,
        formattedSubtotal: formatCurrency(state.subtotal),
        formattedPlatformFee: formatCurrency(state.platformFee),
        formattedTotal: formatCurrency(state.total),
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}